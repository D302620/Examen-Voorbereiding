﻿using System;
using System.Runtime.InteropServices.Marshalling;

class Program
{
    public static void Main()
    {
        int number;

        try
        {
            number = int.Parse(Console.ReadLine());
            char[] charArray = number.ToString().ToCharArray();
            Array.Reverse(charArray);

            string reversed = new string(charArray);

            if (reversed == number.ToString())
            {
                Console.WriteLine(true);
                Console.WriteLine($"{reversed}/{number.ToString()}");
            }
            else
            {
                Console.WriteLine(false);
                Console.WriteLine($"{reversed}/{number.ToString()}");
            }
        }
        catch
        {
            Console.WriteLine("no valid input entered");
        }
    }
}

using H1_oefenen;
using System;
using System.Runtime.ExceptionServices;
using System.Transactions;

class Program
{
    public static void Main()
    {
        bool running = true;
        string choice;
        int height;
        int width;
        int length;
        int radius;
        List<Coaster> coasters = new List<Coaster>();
        for (int i  = 1; i <= 5; i++)
        {
            coasters.Add(new Coaster($"test{i}", $"park{i}", 2010 + i));
        }
        while (running)
        {
            Console.Clear();
            Console.WriteLine("choose option \n1: stop\n2: 1.2\n3: 1.3\n4: 1.4\n5: 1.5\n6: 1.6\n7: 1.7\n8: 1.8\n9: 1.9\n10: 1.10\n11: 1.11");
            choice = Console.ReadLine();
            Console.Clear();
            switch (choice)
            {
                case "1":
                    running = false;
                    break;
                case "2":
                    Console.WriteLine("Height:");
                    height = int.Parse(Console.ReadLine());
                    Console.WriteLine("Width:");
                    width = int.Parse(Console.ReadLine());
                    Console.WriteLine("Length:");
                    length = int.Parse(Console.ReadLine());

                    Console.Clear();
                    Console.WriteLine(width * length * height);
                    Console.ReadLine();
                    break;
                case "3":
                    Console.WriteLine("radius");
                    radius = int.Parse(Console.ReadLine());
                    Console.WriteLine("Height:");
                    height = int.Parse(Console.ReadLine());

                    Console.Clear();
                    Console.WriteLine(Math.Pow(radius, 2) * Math.PI * height);
                    Console.ReadLine();
                    break;
                case "4":
                    int Price;
                    Console.WriteLine("price:");
                    Price = int.Parse(Console.ReadLine());
                    Console.WriteLine("1. 21%\n2. 9%");
                    choice = Console.ReadLine();
                    switch (choice)
                    {
                        case "1":
                            Console.WriteLine($"Price: {Price}\nPrice + btw: {Price * 1.21}\n total added: {Price * 1.21 - Price}");
                            break;
                        case "2":
                            Console.WriteLine($"Price: {Price}\nPrice + btw: {Price * 1.09}\n total added: {Price * 1.09 - Price}");
                            break;
                        default:
                            Console.WriteLine("no option selected");
                            Console.ReadLine();
                            break;
                    }
                    break;

                case "5":
                    for (int i = 0; i <= 30; i++)
                    {
                        if (i % 3 == 0 && i % 5 == 0)
                        {
                            Console.WriteLine("fizzbuzz");
                        }
                        else if (i % 3 == 0)
                        {
                            Console.WriteLine("fizz");
                        }
                        else if (i % 5 == 0)
                        {
                            Console.WriteLine("buzz");
                        }
                        else
                        {
                            Console.WriteLine(i);
                        }
                    }
                    Console.ReadLine();
                    break;

                case "6":
                    foreach (Coaster coaster in coasters)
                    {
                        Console.WriteLine($"name: {coaster.Name} park: {coaster.Name} BuildYear: {coaster.BuildYear}");
                    }
                    Console.ReadLine();
                    break;

                case "7":
                    string name;
                    string park;
                    int buildYear;
                    Console.WriteLine("add new coaster\n");
                    Console.WriteLine("enter name:");
                    name = Console.ReadLine();
                    Console.WriteLine("enter park:");
                    park = Console.ReadLine();
                    Console.WriteLine("enter buildyear:");
                    try
                    {
                        buildYear = int.Parse(Console.ReadLine());

                        Coaster newCoaster = new Coaster(name, park, buildYear);
                        coasters.Add(newCoaster);
                        Console.WriteLine("coaster added");
                        Console.ReadLine();
                    }
                    catch
                    {
                        Console.WriteLine("incorrect info given");
                        Console.ReadLine();
                    }

                    break;

                case "8":
                    int yearMin;
                    int yearMax;

                    try
                    {
                        Console.WriteLine("enter minimum year: ");
                        yearMin = int.Parse(Console.ReadLine());
                        Console.WriteLine("enter maximum year: ");
                        yearMax = int.Parse(Console.ReadLine());
                        foreach (Coaster coaster in coasters)
                        {
                            if (coaster.BuildYear >= yearMin && coaster.BuildYear <= yearMax)
                            {
                                Console.WriteLine($"name: {coaster.Name} park: {coaster.Name} BuildYear: {coaster.BuildYear}");
                            }
                        }
                        Console.ReadLine();
                    }
                    catch
                    {
                        Console.WriteLine("incorrect info given");
                    }
                    break;

                case "9":
                    string fizz = "buzz";
                    string foo = "bar";
                    fizz = foo;
                    foo = fizz;
                    Console.WriteLine(fizz);
                    Console.ReadLine();

                    break;

                case "10":
                    int lastNumber = 0;
                    int number = 1;
                    int nextNumber;

                    for (int i = 0; i < 12; i++)
                    {
                        nextNumber = lastNumber + number;
                        Console.WriteLine($"{nextNumber}, {number}, {lastNumber}");
                        lastNumber = number;
                        number = nextNumber;
                    }
                    Console.ReadLine();


                    break;

                case "11":
                    string text;
                    Console.WriteLine("enter a word");
                    text = Console.ReadLine();
                    char[] characters = text.ToArray();
                    Array.Sort(characters);
                    string aplhabetical = new string(characters);
                    Console.WriteLine(aplhabetical);
                    Console.ReadLine();

                    break;
                default:
                    break;
            }
        }
    }
} 


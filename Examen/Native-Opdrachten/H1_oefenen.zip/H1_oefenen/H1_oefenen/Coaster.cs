﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H1_oefenen
{
    internal class Coaster
    {
        public string Name;
        public string Park;
        public int BuildYear;

        public Coaster(string name, string park, int buildYear)
        {
            Name = name;
            Park = park;
            BuildYear = buildYear;
        }
    }
}

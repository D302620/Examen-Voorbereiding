﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleWebserver
{
    internal class Chat
    {
        public List<Message> messages { get; set; } = new List<Message>();
    }
}

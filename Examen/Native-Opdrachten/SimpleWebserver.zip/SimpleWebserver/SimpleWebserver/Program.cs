﻿using System.Net;
using System.Runtime.Serialization;
using System.Text.Json;

namespace SimpleWebserver
{
    internal class Program
    {
        private static List<Chat> chatRooms = new List<Chat>();

        static void Main(string[] args)
        {
            string url = "http://localhost:8080/";
            Console.WriteLine("Starting webserver.");
            HttpListener listener = new HttpListener();
            listener.Prefixes.Add(url);
            listener.Start();

            Console.WriteLine("Started listener on {0}", url);
            

            while (true)
            {
                HttpListenerContext context = listener.GetContext();
                HttpListenerRequest request = context.Request;
                Console.WriteLine("Received request {0}", request.Url);

                HttpListenerResponse response = context.Response;
                string responseString = "";
                //string responseString = "<html><body>Hello</body></html>";
                if (request.Url.AbsolutePath == "/send-message")
                {
                    int chatroom = int.Parse(request.QueryString["room"]);
                    string messages = request.QueryString["Message"];
                    string author = request.QueryString["author"];
                    Chat foundChat = null;

                    if (chatroom < chatRooms.Count) 
                    {
                        foundChat = chatRooms[chatroom];
                    }
                    else
                    {
                        foundChat = new Chat();
                        chatRooms.Add(foundChat);
                    }

                    foundChat.messages.Add(new Message
                    {
                        Author = author,
                        Text = messages
                    });

                    responseString = "<html><body>message sent</body></html>";

                }

                if (request.Url.AbsolutePath == "/get-messages")
                {
                    int chatroom = int.Parse(request.QueryString["room"]);
                    try
                    {
                        Chat foundChat = chatRooms[chatroom];
                        var formattedMessage = foundChat.messages.Select(m => $"{m.Author}: {m.Text}");
                        responseString = string.Join("\n", formattedMessage);
                    }
                    catch 
                    {
                        responseString = "<html><body>404 not found</body></html>";
                        response.StatusCode = 404;
                    }


                }

                byte[] buffer = System.Text.Encoding.UTF8.GetBytes(responseString);
                response.ContentLength64 = buffer.Length;

                System.IO.Stream output = response.OutputStream;
                output.Write(buffer, 0, buffer.Length);
                output.Close();
                Console.WriteLine("Response sent {0}", responseString);
            }
            listener.Stop();
            Console.WriteLine("Stopped listener");
        }
    }
}

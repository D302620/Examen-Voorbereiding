﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiplayerClasses
{
    internal class Game
    {
        public string Name { get; set; }
        public List<Team> Teams { get; set; }

        public Game(string name) 
        { 
            Name = name;
            Teams = new List<Team>();
        }
    }
}

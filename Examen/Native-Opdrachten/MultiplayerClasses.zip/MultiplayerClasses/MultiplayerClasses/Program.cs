﻿using MultiplayerClasses;

class Program
{
    public static void Main()
    {
        List<Player> players = new List<Player>();
        for(int i = 1; i <= 8; i++)
        {
            players.Add(new Player($"player{i}", i, i, i));
        }

        Team team1 = new Team("team1");
        Team team2 = new Team("team2");

        Game game = new Game("game1");

        for (int i = 0; i < players.Count; i++) 
        {
            if (i < players.Count / 2)
            {
                team1.Players.Add(players[i]);
            }
            else
            {
                team2.Players.Add(players[i]);
            }
        }
        game.Teams.Add(team1);
        game.Teams.Add(team2);

        Console.WriteLine($"{game.Name}");
        foreach (Team team in game.Teams)
        {
            Console.WriteLine($"    {team.Name}");
            foreach (Player player in team.Players)
            {
                player.Team = team;
                Console.WriteLine($"        {player.Name}, {player.Team.Name}, {player.Score}, {player.Level}, {player.Lives}");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiplayerClasses
{
    internal class Player
    {
        public string Name { get; set; }
        public int Score { get; set; }
        public int Level { get; set; }
        public int Lives { get; set; }

        public Team Team { get; set; } 

        public Player(string name, int score, int level, int lives)
        {
            Name = name;
            Score = score;
            Level = level;
            Lives = lives;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPG_Classes
{
    internal class Game
    {
        public bool Battle(Player player, Enemy enemy)
        {
            bool win = true;
            Console.Clear();
            Console.WriteLine($"{player.Name} (lv{player.Level}) vs {enemy.Name} (lv{enemy.Level})");
            if (player.Level < enemy.AttackPower)
            {
                Console.WriteLine($"{enemy.Name} wins");
                win = false;
            }
            else if (player.Level > enemy.AttackPower)
            {
                Console.WriteLine($"{player.Name} wins");
                player.ExperiencePoints += 10;
                Console.WriteLine("\nyou got 10 xp");
                if (player.ExperiencePoints >= 100)
                {
                    player.Level += 1;
                    player.ExperiencePoints = 0;
                    Console.WriteLine("you leveled up!");
                }
                win = true;
            }
            else if (player.Level == enemy.AttackPower) 
            {
                Console.WriteLine("no winner was decided");
                win = true;
            }
            Console.ReadLine();
            return win;
        }
    }
}

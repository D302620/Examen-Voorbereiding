﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPG_Classes
{
    internal class Character
    {
        public string Name { get; set; }
        public int Level { get; set; }

        public Character(string name, int level) 
        { 
            Name = name;
            Level = level;
        }
    }
}

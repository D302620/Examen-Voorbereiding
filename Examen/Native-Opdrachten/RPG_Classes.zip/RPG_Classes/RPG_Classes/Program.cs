﻿using RPG_Classes;

class Program()
{
    public static void Main()
    {
        bool running = true;
        string choice;
        Player player = new Player("player", 5);
        List<Enemy> enemyList = new List<Enemy>();
        Game game = new Game();
        Random rand = new Random();
        for (int i = 1; i <= 10; i++)
        {
            enemyList.Add(new Enemy($"enemy{i}", i, i));
        }
        while (running)
        {
            Console.Clear();
            Console.WriteLine("1. choose apponent\n2. random apponent\nx. stop");
            choice = Console.ReadLine();
            switch (choice.ToUpper())
            {
                case "1":
                    int counter = 1;
                    Console.Clear();
                    foreach (Enemy enemy in enemyList)
                    {
                        Console.WriteLine($"{counter}.{enemy.Name} (lv{enemy.Level})");
                        counter++;
                    }
                    Console.WriteLine("choose an apponent");
                    try
                    {
                        choice = Console.ReadLine();
                        game.Battle(player, enemyList[int.Parse(choice) - 1]);
                    }
                    catch 
                    {
                        Console.Clear();
                        Console.WriteLine("enemy not found");
                        Console.ReadLine();
                    }
                    break;
                case "2":
                    running = game.Battle(player, enemyList[rand.Next(0, enemyList.Count)]);
                    break;
                 case "X":
                    running = false;
                    break;
                default:
                    break;
            }
        }
    }
}

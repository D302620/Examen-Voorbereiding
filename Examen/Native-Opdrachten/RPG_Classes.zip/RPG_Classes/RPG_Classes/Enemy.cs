﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPG_Classes
{
    internal class Enemy : Character
    {
        public int AttackPower { get; set; }

        public Enemy(string name, int level,int attackPower) : base(name, level) 
        {
            AttackPower = attackPower;
        }
    }
}

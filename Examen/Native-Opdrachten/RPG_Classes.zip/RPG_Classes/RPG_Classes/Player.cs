﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPG_Classes
{
    internal class Player : Character
    {
        public int ExperiencePoints { get; set; }

        public Player(string name, int level) : base(name, level) 
        { 
            ExperiencePoints = 0;
        }
    }
}
